"""CADHY Blender Module - UI, operators, and properties."""
