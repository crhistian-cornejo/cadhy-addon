"""CADHY Properties Module - Blender property groups."""
