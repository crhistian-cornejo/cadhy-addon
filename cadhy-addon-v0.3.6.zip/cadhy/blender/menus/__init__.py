"""
CADHY Menus Module
Pie menus and context menus for quick access.
"""
