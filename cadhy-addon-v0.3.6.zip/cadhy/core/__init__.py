"""CADHY Core Module - Geometry and data logic independent of Blender UI."""
