"""CADHY Model Module - Data structures and parameters."""
